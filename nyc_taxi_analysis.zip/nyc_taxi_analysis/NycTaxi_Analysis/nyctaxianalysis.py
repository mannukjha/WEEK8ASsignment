# Databricks notebook or .py script

# =======================
# Step 1: Imports
# =======================
from pyspark.sql.functions import *
from pyspark.sql.types import *

# =======================
# Step 2: Load Data into DBFS
# =======================
# Sample CSV link
dataset_url = "https://s3.amazonaws.com/nyc-tlc/trip+data/yellow_tripdata_2020-01.csv"

# Download & load data from URL (can be uploaded manually too)
file_path = "/mnt/nyc/yellow_tripdata_2020-01.csv"

# Load CSV into DataFrame
df = spark.read.option("header", True).option("inferSchema", True).csv(file_path)

# Create Temp View for SQL use
df.createOrReplaceTempView("taxi_data")

# =======================
# Step 3: Flatten JSON Fields (if any)
# =======================
# In this dataset, no JSON fields exist. If present:
# from_json(col("json_column"), schema) and then select fields.

# =======================
# Step 4: Query 1 - Add Revenue Column
# =======================
df1 = df.withColumn("Revenue", 
    col("fare_amount") + col("extra") + col("mta_tax") + 
    col("improvement_surcharge") + col("tip_amount") + 
    col("tolls_amount") + col("total_amount")
)
df1.select("Revenue").show(5)

# =======================
# Query 2 - Total Passengers by Area (pickup location)
# =======================
df2 = df.groupBy("PULocationID").agg(sum("passenger_count").alias("Total_Passengers")) \
    .orderBy(desc("Total_Passengers"))
df2.show(5)

# =======================
# Query 3 - Real-time Avg Fare / Total Earning by Vendor
# =======================
df3 = df.groupBy("vendorID").agg(
    avg("fare_amount").alias("Average_Fare"),
    sum("total_amount").alias("Total_Earnings")
)
df3.show()

# =======================
# Query 4 - Moving Count of Payments by Payment Type
# =======================
df4 = df.groupBy(window("tpep_pickup_datetime", "5 minutes"), "payment_type") \
    .agg(count("*").alias("Payment_Count")) \
    .orderBy("window")
df4.show(5, truncate=False)

# =======================
# Query 5 - Top 2 Vendors by Earnings on a Date
# =======================
query_date = "2020-01-15"
df5 = df.filter(to_date("tpep_pickup_datetime") == query_date) \
    .groupBy("vendorID") \
    .agg(
        sum("total_amount").alias("Total_Earnings"),
        sum("passenger_count").alias("Total_Passengers"),
        sum("trip_distance").alias("Total_Distance")
    ).orderBy(desc("Total_Earnings")).limit(2)
df5.show()

# =======================
# Query 6 - Most No of Passengers Between Two Locations (Route)
# =======================
df6 = df.groupBy("PULocationID", "DOLocationID") \
    .agg(sum("passenger_count").alias("Passenger_Count")) \
    .orderBy(desc("Passenger_Count")).limit(1)
df6.show()

# =======================
# Query 7 - Top Pickup Locations in Last 5/10 Seconds
# =======================
from pyspark.sql.window import Window

# Simulate stream with timestamp
df_stream = df.withColumn("pickup_time", col("tpep_pickup_datetime").cast("timestamp"))

windowed_df = df_stream \
    .withWatermark("pickup_time", "1 minute") \
    .groupBy(window("pickup_time", "10 seconds"), "PULocationID") \
    .agg(sum("passenger_count").alias("Passengers")) \
    .orderBy(desc("Passengers"))

windowed_df.show(5, truncate=False)

# =======================
# Save Final DataFrame as External Parquet Table
# =======================
output_path = "/mnt/nyc/output_parquet"
df1.write.mode("overwrite").parquet(output_path)

# Register as external table
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS nyc_taxi_analysis
    USING PARQUET
    LOCATION '{output_path}'
""")
